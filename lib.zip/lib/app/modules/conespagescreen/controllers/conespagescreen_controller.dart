import 'package:get/get.dart';

class ConespagescreenController extends GetxController {
  //TODO: Implement ConespagescreenController

  final count = 0.obs;
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {
    super.onClose();
  }

  void increment() => count.value++;
}
