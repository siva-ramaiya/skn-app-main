
import 'package:get/get.dart';

class SplashscreenpageController extends GetxController {
 
  
}
