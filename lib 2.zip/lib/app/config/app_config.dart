class AppConfig {
  static const String baseUrl = "https://api.skandaswamyandsons.com"; 
  // static const String baseUrl = "http://localhost:3000";
  // static const String baseUrl = "http://10.228.139.183:3000";
  // or http://192.168.x.x:3000 if running locally
}
