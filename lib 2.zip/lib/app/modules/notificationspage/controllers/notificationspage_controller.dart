import 'package:get/get.dart';

class NotificationspageController extends GetxController {
 var allowNotifications = true.obs;
  var emailNotifications = false.obs;
  var orderNotifications = false.obs;
  var generalNotifications = true.obs;
  
  
}
